#!/bin/bash
docker build -t dshop.services.orders:local .