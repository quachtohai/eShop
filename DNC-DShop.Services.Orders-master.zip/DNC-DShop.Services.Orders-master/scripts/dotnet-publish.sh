#!/bin/bash
dotnet publish ./src/DShop.Services.Orders -c Release -o ./bin/docker