#!/bin/bash
docker build -t dshop.services.orders:local -f Dockerfile.multistage .