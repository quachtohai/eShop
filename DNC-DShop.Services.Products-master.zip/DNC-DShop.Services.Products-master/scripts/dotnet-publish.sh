#!/bin/bash
dotnet publish ./src/DShop.Services.Products -c Release -o ./bin/docker