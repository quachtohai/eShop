#!/bin/bash
dotnet publish ./src/DShop.Services.Operations -c Release -o ./bin/docker