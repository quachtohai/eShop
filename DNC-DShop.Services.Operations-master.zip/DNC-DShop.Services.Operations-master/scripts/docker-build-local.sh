#!/bin/bash
docker build -t dshop.services.operations:local .