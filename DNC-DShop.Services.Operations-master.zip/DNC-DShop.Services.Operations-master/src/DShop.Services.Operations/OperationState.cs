namespace DShop.Services.Operations
{
    public enum OperationState
    {
        Pending,
        Completed,
        Rejected
    }
}