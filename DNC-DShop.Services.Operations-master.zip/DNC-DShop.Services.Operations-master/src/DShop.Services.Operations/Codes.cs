namespace DShop.Services.Operations
{
    public class Codes
    {
        public static string Success => "success";
        public static string Error => "error";       
    }
}