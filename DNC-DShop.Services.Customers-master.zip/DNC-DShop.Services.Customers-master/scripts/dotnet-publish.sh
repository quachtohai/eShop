#!/bin/bash
dotnet publish ./src/DShop.Services.Customers -c Release -o ./bin/docker