#!/bin/bash
docker build -t dshop.services.customers:local -f Dockerfile.multistage .