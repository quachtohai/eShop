namespace DShop.Api.Queries
{
    public class BrowseCustomers : PagedQuery
    {
    }
}