#!/bin/bash
dotnet publish ./src/DShop.Api -c Release -o ./bin/docker