#!/bin/bash
docker build -t dshop.api:local -f Dockerfile.multistage .