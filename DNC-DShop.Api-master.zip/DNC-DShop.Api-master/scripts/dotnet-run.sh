#!/bin/bash
export ASPNETCORE_ENVIRONMENT=local
cd src/DShop.Api
dotnet run --no-restore