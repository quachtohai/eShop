#!/bin/bash
dotnet publish ./src/DShop.Services.Identity -c Release -o ./bin/docker