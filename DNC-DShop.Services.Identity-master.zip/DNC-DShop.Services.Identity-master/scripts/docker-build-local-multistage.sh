#!/bin/bash
docker build -t dshop.services.identity:local -f Dockerfile.multistage .