namespace DShop.Common.Messages
{
    //Marker
    public interface IEvent : IMessage
    {
    }
}