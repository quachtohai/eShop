namespace DShop.Common.Messages
{
    //Marker
    public interface IMessage
    {
    }
}