namespace DShop.Common.Messages
{
    public interface IResource
    {
        Resource Resource { get; }
    }
}