namespace DShop.Common.Mongo
{
    public interface IMongoDbInitializer : IInitializer
    {
    }
}