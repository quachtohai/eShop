namespace DShop.Common.Logging
{
    public class SerilogOptions
    {
        public bool ConsoleEnabled { get; set; }
        public string Level { get; set; }
    }
}