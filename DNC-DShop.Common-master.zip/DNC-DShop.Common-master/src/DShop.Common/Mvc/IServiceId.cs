namespace DShop.Common.Mvc
{
    public interface IServiceId
    {
         string Id { get; }
    }
}