namespace DShop.Common
{
    public class AppOptions
    {
        public string Name { get; set; }
    }
}