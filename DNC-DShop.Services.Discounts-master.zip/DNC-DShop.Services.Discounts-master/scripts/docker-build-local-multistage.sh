#!/bin/bash
docker build -t dshop.services.discounts:local -f Dockerfile.multistage .