#!/bin/bash
dotnet publish ./src/DShop.Services.Discounts -c Release -o ./bin/docker