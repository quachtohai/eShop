#!/bin/bash
export ASPNETCORE_ENVIRONMENT=local
cd src/DShop.Services.Discounts
dotnet run --no-restore