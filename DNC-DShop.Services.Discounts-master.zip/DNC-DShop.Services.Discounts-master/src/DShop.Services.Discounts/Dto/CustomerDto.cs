using System;

namespace DShop.Services.Discounts.Dto
{
    public class CustomerDto
    {
        public Guid Id { get; set; }
        public string Email { get; set; }
    }
}