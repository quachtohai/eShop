namespace DShop.Services.Discounts.Dto
{
    public class DiscountDetailsDto
    {
        public CustomerDto Customer { get; set; }
        public DiscountDto Discount { get; set; }
    }
}