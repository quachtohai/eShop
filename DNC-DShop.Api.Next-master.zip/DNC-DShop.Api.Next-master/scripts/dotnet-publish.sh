#!/bin/bash
dotnet publish --no-restore ./src/DShop.Api.Next -c Release -o ./bin/docker