#!/bin/bash
export ASPNETCORE_ENVIRONMENT=local
cd src/DShop.Api.Next
dotnet run --no-restore