#!/bin/bash
dotnet build --no-cache 