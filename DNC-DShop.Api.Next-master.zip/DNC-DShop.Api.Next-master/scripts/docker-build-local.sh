#!/bin/bash
docker build -t dshop.api.next:local .