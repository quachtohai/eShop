#!/bin/bash
dotnet publish ./src/DShop.Services.Notifications -c Release -o ./bin/docker