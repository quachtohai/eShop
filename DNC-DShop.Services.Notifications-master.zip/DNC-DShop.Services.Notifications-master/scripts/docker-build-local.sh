#!/bin/bash
docker build -t dshop.services.notifications:local .