#!/bin/bash
dotnet build