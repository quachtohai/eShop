#!/bin/bash
docker build -t dshop.services.signalr:local -f Dockerfile.multistage .