#!/bin/bash
dotnet publish ./src/DShop.Services.Signalr -c Release -o ./bin/docker