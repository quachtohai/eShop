#!/bin/bash
docker build -t dshop.services.signalr:local .