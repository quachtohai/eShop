namespace DShop.Services.Signalr.Framework
{
    public class SignalrOptions
    {
        public string Backplane { get; set; }
        public string Hub { get; set; }
    }
}